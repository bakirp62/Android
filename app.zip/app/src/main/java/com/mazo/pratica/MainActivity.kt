package com.mazo.pratica

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore.Audio.Radio
import android.text.Editable
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val botom: Button = findViewById(R.id.button2)
        botom.setOnClickListener {Respuestas()}
    }
    private fun Respuestas() {
        val numero: EditText =findViewById(R.id.Ingresa)

       val Radio1: RadioButton =findViewById(R.id.Btn1)

        //val Radio2: RadioButton =findViewById(R.id.Btn2)

        val Check1 : CheckBox = findViewById(R.id.check1)

        var todo = numero.text
       numero.text = todo
        Toast.makeText(this,"Numero Ingresado es: $todo",Toast.LENGTH_LONG).show()

       //todo = Radio1.text
        //Radio1.text = todo
        Toast.makeText(this,"El Radio es 1: $todo",Toast.LENGTH_LONG).show()

     // var todo3 = Radio2.text
       // Radio2.text = todo3
        //Toast.makeText(this,"El Radio es 2: $todo3",Toast.LENGTH_LONG).show()


         //todo = Check1.text
        //Check1.text = todo
        Toast.makeText(this,"El Check es : $todo",Toast.LENGTH_LONG).show()


    }


}